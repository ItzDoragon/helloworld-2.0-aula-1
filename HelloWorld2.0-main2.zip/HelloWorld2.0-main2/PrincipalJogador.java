package JogoDaVelha;
import java.util.Scanner;
public class PrincipalJogador {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[][] arrayInt = new int[10][5];
        for(int i=0; i<arrayInt.length; i++)
            for(int j=0; j<arrayInt[i].length; j++)
                arrayInt[i][j] = -1;

        Jogador[][] jogadores = new Jogador[1][1];
        for(int i=0; i<jogadores.length; i++)
            for(int j=0; j<jogadores[i].length; j++) {
                System.out.print("Nome do jogador da posição ["+i+"]["+j+"]: ");
                String nome = teclado.nextLine();
                System.out.print("ID do jogador da posição ["+i+"]["+j+"]: ");
                int id = Integer.parseInt(teclado.nextLine());
                System.out.print("Símbolo do jogador da posição ["+i+"]["+j+"]: ");
                char simbolo = teclado.nextLine().charAt(0);
                jogadores[i][j] = new Jogador(nome, id, simbolo);
                System.out.println("---------------");
            }
        for(int i=0; i<jogadores.length; i++)
            for(int j=0; j<jogadores[i].length; j++)
                System.out.println(jogadores[i][j]);
        teclado.close();
    }
    }
